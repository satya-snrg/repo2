/**
 * --------------------------------------------------------------------------
 * CoreUI Free Boostrap Admin Template (v2.0.0-beta.5): tooltips.js
 * Licensed under MIT (https://coreui.io/license)
 * --------------------------------------------------------------------------
 */
var TooltipsView = function ($) {
  $('[data-toggle="tooltip"]').tooltip();
  return TooltipsView;
}($);
//# sourceMappingURL=tooltips.js.map