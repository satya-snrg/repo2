import $ from 'jquery'

/**
 * --------------------------------------------------------------------------
 * CoreUI Free Boostrap Admin Template (v2.0.0-beta.5): tooltips.js
 * Licensed under MIT (https://coreui.io/license)
 * --------------------------------------------------------------------------
 */

const TooltipsView = (($) => {
  $('[data-toggle="tooltip"]').tooltip()

  return TooltipsView
})($)
